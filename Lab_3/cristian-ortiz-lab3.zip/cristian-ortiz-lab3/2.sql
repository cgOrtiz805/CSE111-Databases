SELECT s_name AS name, MIN(s_acctbal) AS balance
FROM supplier;
